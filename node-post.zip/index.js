const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());

app.get("/endpoint", function (req, res) {
  console.log(req.query, "params");
  res.send(req.query);
  return true;
});

app.listen(3000);
console.log("node express app started at http://localhost:3000");
